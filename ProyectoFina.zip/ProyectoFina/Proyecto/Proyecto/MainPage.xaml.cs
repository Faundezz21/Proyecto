﻿using System;
using System.Collections.Generic;
namespace Proyecto
{
    public partial class MainPage : ContentPage
    {
        // Colección 
        List<Mesero> meseros = new List<Mesero>();

        public MainPage()
        {
            InitializeComponent();
        }
        // Boton guardar 
        private void GuardarButton_Clicked(object sender, EventArgs e)
        {
            
            string rut = Rut.Text; //pasa lo que esta en el textbox a rut
            string nombre = Nombre.Text;
            string apellidoPaterno = ApellidoPaterno.Text;
            string apellidoMaterno = ApellidoMaterno.Text;
            int dia = int.Parse(Dia.Text);
            int mes = int.Parse(Mes.Text);
            int anio = int.Parse(Anio.Text);
            string genero = HombreRadioButton.IsChecked ? "Hombre" : "Mujer";//sirve para comprobar que boton esta seleccionado

            // Crea un objeto Mesero
            Mesero nuevoMesero = new Mesero
            {
                Rut = rut,
                Nombre = nombre,
                ApellidoPaterno = apellidoPaterno,
                ApellidoMaterno = apellidoMaterno,
                FechaNacimiento = new DateTime(anio, mes, dia),
                Genero = genero
            };

            // Agrega el nuevo mesero a la colección
            meseros.Add(nuevoMesero);

            // Cada vez que se da en guardar limpia la "terminal" es como cuando se inicializa en 0 cuando no hay nada
            Rut.Text = "";
            Nombre.Text = "";
            ApellidoPaterno.Text = "";
            ApellidoMaterno.Text = "";
            Dia.Text = "";
            Mes.Text = "";
            Anio.Text = "";
            HombreRadioButton.IsChecked = false;//lo que hace esto es desmarcar la opcion
            MujerRadioButton.IsChecked = false;//lo que hace esto es desmarcar la opcion
        }
        private void MostrarDatosButton_Clicked(object sender, EventArgs e)//mostrar ,la base de datos
        {
            if (meseros.Count > 0)
            {
                string datos = "Datos de Meseros:\n";
                foreach (var mesero in meseros)
                {
                    datos += $"Rut: {mesero.Rut}\n";
                    datos += $"Nombre: {mesero.Nombre}\n";
                    datos += $"Apellido Paterno: {mesero.ApellidoPaterno}\n";
                    datos += $"Apellido Materno: {mesero.ApellidoMaterno}\n";
                    datos += $"Fecha de Nacimiento: {mesero.FechaNacimiento.ToShortDateString()}\n";//para el tema de la fecha que no reciba tantos datos
                    datos += $"Género: {mesero.Genero}\n";
                    datos += "\n";
                }

                DisplayAlert("Datos de Meseros", datos, "OK");
            }
            else
            {
                DisplayAlert("Datos de Meseros", "No hay meseros guardados.", "OK");
            }
        }

    }

    // Define la clase Mesero
    public class Mesero
    {
        public string Rut { get; set; }
        public string Nombre { get; set; }
        public string ApellidoPaterno { get; set; }
        public string ApellidoMaterno { get; set; }
        public DateTime FechaNacimiento { get; set; }
        public string Genero { get; set; }
    }
}
